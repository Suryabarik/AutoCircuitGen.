def percentage():
      if num1>num2 :
            print(f"The percentage of {num2}/{num1}  is:", (num2/num1)*100, "%")
      else :
            print(f"The percentage of {num1}/{num2}  is:", (num1/num2)*100 , "%")
num1 = float(input("Enter 1st no.: "))
num2 = float(input("Enter 2nd no.: "))

if __name__ == "__main__":
      percentage()

