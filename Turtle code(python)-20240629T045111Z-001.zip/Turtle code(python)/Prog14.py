
def is_even_or_odd():
    if num % 2 == 0:
        print(f"{num} is a Even no.") 
    else:
        print(f"{num} is a Odd no.")
num = int(input("Enter a no.: ")) 
if __name__ == "__main__":
    is_even_or_odd()