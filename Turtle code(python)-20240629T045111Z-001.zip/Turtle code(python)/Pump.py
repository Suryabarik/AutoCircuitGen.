import turtle as t

t.pensize(2)
t.setheading(90)
t.forward(100)
t.setheading(0)
t.forward(100)
t.setheading(270)
t.forward(100)
t.setheading(180)
t.forward(100)

t.penup()
t.goto(50 , 100)
t.pendown()
t.setheading(90)
t.forward(50)

t.penup()
t.goto(100 , 50)
t.pendown()
t.setheading(0)
t.forward(50)

t.penup()
t.goto(40 , 50)
t.pendown()
t.write("PUMP" , font=("Arial", 10, "bold"))

t.done()