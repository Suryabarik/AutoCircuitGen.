import turtle
import json

# Create a turtle object
t = turtle.Turtle()

# Read the JSON file with drawing instructions
with open('C:\\Users\\HP\\Desktop\\json1\\register25.json', 'r') as json_file:
    data = json.load(json_file)

# Loop through the instructions and execute Turtle commands
# Loop through the commands and execute actions
for command in data["commands"]:
    action = command["action"]
    if action == "goto":
        x = command.get("x", 0)  # Default to 0 if "x" is not present in the command
        y = command.get("y", 0)  # Default to 0 if "y" is not present in the command
        t.goto(x, y)
    elif action == "setheading":
        angle = command.get("angle", 0)  # Default to 0 if "angle" is not present in the command
        t.setheading(angle)
    elif action == "forward":
        distance = command.get("distance", 0)  # Default to 0 if "distance" is not present in the command
        t.forward(distance)
    elif action == "right":
        angle = command.get("angle", 0)  # Default to 0 if "angle" is not present in the command
        t.right(angle)
    elif action == "penup":
        t.penup()
    elif action == "pendown":
        t.pendown()
    elif action == "circle":
        radius = command.get("radius", 0)  # Default to 0 if "radius" is not present in the command
        extent = command.get("extent", 360)  # Default to 360 if "extent" is not present in the command
        t.circle(radius, extent)
    elif action == "duration":
            duration = command.get("duration", 1)
            # Sleep for the specified duration (in seconds)
            turtle.ontimer(turtle.bye, int(duration * 1000))   


# Close the turtle graphics window when done
turtle.done()
