import turtle
import json

# Initialize the Turtle screen
window = turtle.Screen()
window.title("Turtle JSON Commands")
t = turtle.Turtle()

def execute_commands(commands):
    for command in commands:
        action = command["action"]
        
        if action == "forward":
            t.forward(command["value"])
        elif action == "backward":
            t.backward(command["value"])
        elif action == "left":
            t.left(command["value"])
        elif action == "right":
            t.right(command["value"])
        elif action == "pen_up":
            t.penup()
        elif action == "pen_down":
            t.pendown()
        elif action == "color":
            t.color(command["value"])
        else:
            print(f"Unknown action: {action}")

# Specify the JSON file containing commands
json_file = "C:\\Users\\HP\\Desktop\\json1\\register1.json"

try:
    with open(json_file, "r") as file:
        commands_data = json.load(file)
        execute_commands(commands_data)
except FileNotFoundError:
    print(f"File not found: {json_file}")
except json.JSONDecodeError:
    print(f"Invalid JSON in file: {json_file}")
finally:
    window.exitonclick()
