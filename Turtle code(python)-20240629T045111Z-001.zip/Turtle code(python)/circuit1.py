import turtle
import json

# Create a turtle object
t = turtle.Turtle()

# Read the JSON data with drawing instructions
json1 = {
  "title": "Turtle Graphics",
  "commands": [
    {"action": "penup"},
    {"action": "goto", "x": -70, "y": -35},
    {"action": "pendown"},
    {"action": "setheading", "angle": 0},
    {"action": "forward", "distance": 50},
    {"action": "penup"},
    {"action": "goto", "x": -20, "y": -50},
    {"action": "pendown"},
    {"action": "setheading", "angle": 90},
    {"action": "forward", "distance": 30},
    {"action": "penup"},
    {"action": "goto", "x": 70, "y": -35},
    {"action": "pendown"},
    {"action": "setheading", "angle": 0},
    {"action": "forward", "distance": 90},
    {"action": "penup"},
    {"action": "goto", "x": 10, "y": 150},
    {"action": "pendown"},
    {"action": "setheading", "angle": 0},
    {"action": "forward", "distance": 150},
    {"action": "penup"},
    {"action": "goto", "x": 10, "y": 140},
    {"action": "pendown"},
    {"action": "setheading", "angle": 90},
    {"action": "forward", "distance": 20},
    {"action": "penup"},
    {"action": "goto", "x": -5, "y": 150},
    {"action": "pendown"},
    {"action": "setheading", "angle": 0},
    {"action": "backward", "distance": 70},
    {"action": "penup"},
    {"action": "goto", "x": -10, "y": "133"},
    {"action": "pendown"},
    {"action": "setheading", "angle": 90},
    {"action": "forward", "distance": 35},
    {"action": "penup"},
    {"action": "goto", "x": -75, "y": 150},
    {"action": "pendown"},
    {"action": "circle", "radius": 3},
    {"action": "penup"},
    {"action": "goto", "x": -150, "y": 150},
    {"action": "pendown"},
    {"action": "circle", "radius": 3},
    {"action": "setheading", "angle": 0},
    {"action": "goto", "x": -80, "y": 175},
    {"action": "circle", "radius": 3},
    {"action": "penup"},
    {"action": "goto", "x": -157, "y": 150},
    {"action": "pendown"},
    {"action": "setheading", "angle": 0},
    {"action": "backward", "distance": 60},
    {"action": "right", "angle": 90},
    {"action": "forward", "distance": 50},
    {"action": "penup"},
    {"action": "goto", "x": -237, "y": 60},
    {"action": "pendown"},
    {"action": "setheading", "angle": 30},
    {"action": "forward", "distance": 50},
    {"action": "penup"},
    {"action": "goto", "x": -194, "y": 60},
    {"action": "pendown"},
    {"action": "setheading", "angle": 145},
    {"action": "forward", "distance": 50},
    {"action": "penup"},
    {"action": "goto", "x": -70, "y": -35},
    {"action": "pendown"},
    {"action": "setheading", "angle": 180},
    {"action": "backward", "distance": 145},
    {"action": "right", "angle": 90},
    {"action": "forward", "distance": 86}
  ]
}

# Loop through the commands and execute actions
for command in json1["commands"]:
    action = command["action"]
    if action == "goto":
        x = command.get("x", 0)
        y = command.get("y", 0)
        t.goto(x, y)
    elif action == "setheading":
        angle = command.get("angle", 0)
        t.setheading(angle)
    elif action == "forward":
        distance = command.get("distance", 0)
        t.forward(distance)
    elif action == "right":
        angle = command.get("angle", 0)
        t.right(angle)
    elif action == "penup":
        t.penup()
    elif action == "pendown":
        t.pendown()
    elif action == "circle":
        radius = command.get("radius", 0)
        t.circle(radius)

# Close the turtle graphics window when done
turtle.done()
