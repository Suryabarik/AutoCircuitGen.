from Basicprograms.Prog4 import multification
import math

def area_rectangle():
    length = int(input("Enter the length:"))
    width = int(input("Enter the width:"))
    area = multification(length , width)
    print("The area of rectangle is:" , area)
area_rectangle()

def perimeter_rectangle():
    length = int(input("Enter the length:"))
    width = int(input("Enter the width:"))
    print("The perimeter of rectangle is:" ,  2*(length+width))

    

if __name__ == "__main__":
    area_rectangle()
    perimeter_rectangle()
    


