import turtle as t

t.penup()
t.goto(-100 , 0)
t.pendown()
t.pensize(2)

t.setheading(90)
t.forward(100)
t.setheading(0)
t.forward(200)
t.setheading(270)
t.forward(100)
t.setheading(180)
t.forward(200)
t.pensize(1)

#Left Side
t.penup()
t.goto(-100 , 80)
t.pendown()
t.setheading(180)
t.forward(100)

t.penup()
t.goto(-235 , 80)
t.pendown()
t.write("BAT+")

t.penup()
t.goto(-90 , 72)
t.pendown()
t.write("+", font=("Arial", 14, "bold"))

#Right Side
t.penup()
t.goto(100 , 80)
t.pendown()
t.setheading(0)
t.forward(100)
t.setheading(270)
t.forward(30)

t.pensize(2)  #GND
t.setheading(0)
t.forward(30)
t.backward(60)
t.penup()
t.goto(200 , 42)
t.pendown()
t.setheading(0)
t.forward(15)
t.backward(30)
t.penup()
t.goto(200 , 34)
t.pendown()
t.setheading(0)
t.forward(7.5)
t.backward(15)
t.pensize(1)

t.penup()
t.goto(-50 , 48)
t.pendown()
t.write("Li+ Battery" , font=("Arial", 14, "bold"))

t.done()