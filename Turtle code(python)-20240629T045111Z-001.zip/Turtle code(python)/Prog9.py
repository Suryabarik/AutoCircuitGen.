import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score

# Load data from an Excel file (replace 'your_data.xlsx' with your file)
excel_file = 'C:\\Users\\HP\\Desktop\\nlpDataset.xlsx'
df = pd.read_excel(excel_file)

# Assuming your Excel file has 'Questions' and 'Answers' columns
questions = df['QUESTIONS'].tolist()
answers = df['ANSWERS'].tolist()

# Split the data into training and testing sets
train_questions, test_questions, train_answers, test_answers = train_test_split(questions, answers, test_size=0.2, random_state=42)

# Create TF-IDF vectorizer
vectorizer = TfidfVectorizer()

# Transform the training and testing data
X_train = vectorizer.fit_transform(train_questions)
X_test = vectorizer.transform(test_questions)

# Train a simple LinearSVC classifier
classifier = LinearSVC()
classifier.fit(X_train, train_answers)

# Predict on the test set
predictions = classifier.predict(X_test)

# Calculate accuracy
accuracy = accuracy_score(test_answers, predictions)
print(f"Accuracy: {accuracy * 100:.2f}%")

# Interactive loop
while True:
    user_question = input("Enter a question (or type 'exit' to quit): ")
    if user_question.lower() == 'exit':
        break

    # Transform the user's question and predict the answer
    user_question_vector = vectorizer.transform([user_question])
    predicted_answer = classifier.predict(user_question_vector)
    
    print(f"Predicted Answer: {predicted_answer[0]}")
