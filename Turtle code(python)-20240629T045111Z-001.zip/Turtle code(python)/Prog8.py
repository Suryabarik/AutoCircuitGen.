def is_prime():
    num = int(input("Enter a Number: "))
    if num == 1 :
        print(f"{num} is not a  prime no.")
    elif num > 1:
        for i in range(2, num):
            if (num % i) == 0:
                print(f"{num} is not a prime no.")
                break
        else:
            print(f'{num} is a prime number')

if __name__ == "__main__":
    is_prime()
