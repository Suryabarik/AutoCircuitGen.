
def celsius_to_fahrenheit():
    celsius = int(input("Enter the temprature in celcius: "))
    print(f"{celsius}° celcius in fahrenheit is:" ,(celsius * 9/5) + 32,"f")

def fahrenheit_to_celsius():
    fahrenheit=int(input('Enter temperature in Fahrenheit: '))
    print(f"{fahrenheit} Fahrenheit in celcius is:", ((fahrenheit - 32)*5)/9,"°c")

#print()
if __name__ == "__main__":
    celsius_to_fahrenheit()
    fahrenheit_to_celsius()


    

