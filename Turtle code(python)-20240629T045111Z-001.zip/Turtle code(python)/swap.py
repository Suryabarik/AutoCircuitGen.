a = int(input("enter 1st number"))
b = int(input("entert 2nd number"))

print("Before swapping: a =", a, ", b =", b)
temp = a
a = b
b = temp

print("After swapping:")
print("a =", a)
print("b =", b)
