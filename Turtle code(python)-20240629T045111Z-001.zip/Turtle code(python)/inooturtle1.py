import turtle
import json

# Create a turtle object
my_turtle = turtle.Turtle()

# Read the JSON file with drawing instructions
with open('C:\\Users\\HP\\Desktop\\inoojson\\register5.json', 'r') as json_file:
    data = json.load(json_file)

# Loop through the instructions and execute Turtle commands
for command in data["commands"]:
    action = command["action"]
    if action == "goto":
        x = command.get("x", 0)
        y = command.get("y", 0)
        my_turtle.goto(x, y)
    elif action == "setheading":
        angle = command.get("angle", 0)
        my_turtle.setheading(angle)
    elif action == "forward":
        distance = command.get("distance", 0)
        my_turtle.forward(distance)
    elif action == "right":
        angle = command.get("angle", 0)
        my_turtle.right(angle)
    elif action == "penup":
        my_turtle.penup()
    elif action == "pendown":
        my_turtle.pendown()
    elif action == "circle":
        radius = command.get("radius", 0)
        extent = command.get("extent", 360)
        my_turtle.circle(radius, extent)
    elif action == "for":
        # Handle the loop
        range_value = command.get("range", 1)
        for _ in range(range_value):
            # Execute the commands inside the loop
            for loop_command in command.get("commands", []):
                loop_action = loop_command["action"]
                if loop_action == "forward":
                    loop_distance = loop_command.get("distance", 0)
                    my_turtle.forward(loop_distance)
                elif loop_action == "right":
                    loop_angle = loop_command.get("angle", 0)
                    my_turtle.right(loop_angle)
                elif loop_action == "penup":
                    my_turtle.penup()
                elif loop_action == "pendown":
                    my_turtle.pendown()
                # Add more conditions for other actions if needed

# Close the turtle graphics window when done
turtle.done()
