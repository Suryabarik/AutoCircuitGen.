import turtle as t

t.pensize(2)
t.setheading(90)
t.forward(100)
t.setheading(0)
t.forward(300)
t.setheading(270)
t.forward(100)
t.setheading(180)
t.forward(300)

t.pensize(1)
t.penup()
t.goto(0 , 33.3)
t.pendown()
t.setheading(180)
t.forward(100)

t.penup()
t.goto(0 , 66.6)
t.pendown()
t.setheading(180)
t.forward(100)

t.penup()
t.goto(80 , 40)
t.pendown()
t.write("Thermistor" , font=("Arial", 20, "bold"))

t.done()