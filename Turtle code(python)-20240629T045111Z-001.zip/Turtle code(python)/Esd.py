import turtle as t

t.speed(1)
t.penup()
t.goto(150 , 0)
t.pendown()
t.pensize(3)

t.fillcolor("black")  
t.begin_fill() 
t.setheading(90)
for _ in range(3):
    t.forward(100)
    t.right(-120) 
t.end_fill()

t.penup()
t.goto(-24 , 100)
t.pendown()

t.fillcolor("black")  
t.begin_fill() 
t.setheading(270)
for _ in range(3):
    t.forward(100)
    t.right(-120) 
t.end_fill()

t.penup()
t.goto(63 , 50)
t.pendown()
t.pensize(3)
t.setheading(90)
t.forward(100)
t.setheading(150)
t.forward(30)

t.penup()
t.goto(63 , 50)
t.pendown()
t.setheading(270)
t.forward(100)
t.setheading(330)
t.forward(30)

t.penup()
t.goto(63 , 50)
t.pendown()
t.setheading(0)
t.pensize(2)
t.forward(200)
t.backward(400)

t.penup()
t.goto(10 , 190)
t.pendown()
t.write("TVS3301" , font=("Arial", 22, "bold"))

t.done()