import turtle as t

t.speed(1)
t.pensize(2)
t.setheading(90)
t.forward(100)
t.setheading(0)
t.forward(100)
t.setheading(270)
t.forward(100)
t.setheading(180)
t.forward(100)
t.pensize(1)

t.penup()
t.goto(100 , 50)
t.pendown()
t.setheading(0)
t.forward(100)

t.penup()
t.goto(30 , 40)
t.pendown()
t.write("KEYPAD" , font=("Arial", 10, "bold"))

t.done()