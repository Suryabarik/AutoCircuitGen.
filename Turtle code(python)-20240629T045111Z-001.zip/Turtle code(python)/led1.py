import turtle
import cv2
import numpy as np
from PIL import ImageGrab

# Create a turtle object
my_turtle = turtle.Turtle()

# Set the color and width of the lines
my_turtle.color("black")
my_turtle.pensize(3)

# Hide the turtle shape
my_turtle.hideturtle()

# Set the drawing speed
my_turtle.speed(1)  # Adjust the speed as desired

# Set up the turtle screen
screen = turtle.Screen()
screen.setup(width=1000, height=800)

# Function to capture the turtle graphics screen as an image
def get_image():
    x, y, width, height = screen.getcanvas().winfo_rootx(), screen.getcanvas().winfo_rooty(), screen.window_width(), screen.window_height()
    image = ImageGrab.grab((x, y, x + width, y + height))
    return image

# Create a video writer object
output_filename = "C:/Users/shibashish nayak/Downloads/led.avi"
fourcc = cv2.VideoWriter_fourcc(*'XVID')
video_writer = cv2.VideoWriter(output_filename, fourcc, 10, (800, 600))

# Draw the LED
my_turtle.penup()
my_turtle.goto(-50, 0)
my_turtle.pendown()

my_turtle.setheading(60)
my_turtle.forward(100)

my_turtle.setheading(-60)
my_turtle.forward(100)

my_turtle.setheading(-180)
my_turtle.forward(200)

my_turtle.setheading(60)
my_turtle.forward(100)

my_turtle.penup()
my_turtle.goto(-50, 100)
my_turtle.pendown()

my_turtle.setheading(0)
my_turtle.forward(200)

# Capture each frame and write to the video file
while True:
    # Capture the turtle graphics screen as an image
    screen_image = get_image()

    # Convert the image to BGR format for writing with cv2
    frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

    # Write the frame to the video file
    video_writer.write(frame)

    # Update the turtle graphics
    turtle.update()

    # Check for any exit condition
    # If you want to exit the loop based on a condition, add it here
    # For example, press 'q' to quit
    if turtle.Screen().keycode("q"):
        break

# Release the video writer and close the turtle graphics window
video_writer.release()
turtle.bye()
