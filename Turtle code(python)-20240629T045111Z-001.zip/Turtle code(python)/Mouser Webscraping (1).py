#!/usr/bin/env python
# coding: utf-8

# In[10]:


import requests
from bs4 import BeautifulSoup
import csv
import time
from pathlib import Path
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Define common headers
COMMON_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,/;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': 'https://www.google.com/'
}

# Centralized requests.get call
def get_soup(url):
    try:
        response = requests.get(url, headers=COMMON_HEADERS)
        response.raise_for_status()
        return BeautifulSoup(response.text, 'html.parser')
    except requests.HTTPError as e:
        logging.error(f"HTTP error occurred: {e}")
    except Exception as e:
        logging.error(f"An error occurred: {e}")
    return None

# Dynamic product link extraction
def get_product_links(base_url):
    product_links = []
    soup = get_soup(base_url)
    if soup:
        product_link_elements = soup.find_all('a', id=lambda x: x and x.startswith('lnkMfrPartNumber_'))
        for a_tag in product_link_elements:
            if a_tag.has_attr('href'):
                full_url = requests.compat.urljoin(base_url, a_tag['href'])
                product_links.append(full_url)
    return product_links

# Combine the data extraction functions
def extract_product_data(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,/;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'https://www.google.com/'
    }

    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, "html.parser")

    mouser_no = soup.find(id='spnMouserPartNumFormattedForProdInfo').get_text(strip=True)
    mfr_no = soup.find(id='spnManufacturerPartNumber').get_text(strip=True)
    manufacturer_name = soup.find('a', id='lnkManufacturerName').get_text(strip=True)
    description_element = soup.find(id='spnDescription').get_text(strip=True)
    lifecycle_icon = soup.find('i', class_='fa-m-new')
    lifecycle_text = lifecycle_icon.find_next('strong').next_sibling.strip() if lifecycle_icon else "Lifecycle information not found."
    datasheet_link = soup.find('a', {'id': 'pdp-datasheet_0'})
    datasheet_url = datasheet_link['href'] if datasheet_link else "Datasheet link not found."
    Ecad_info_message_div = soup.find(id="cadInfoMessage")
    ecad_model = Ecad_info_message_div.get_text(strip=True) if Ecad_info_message_div else "ECAD Model information not found."

    product_data = [
        ['Product Details', ' '],
        ['Attributes', 'Values'],
        ['Mouser No', mouser_no],
        ['Mfr. No', mfr_no],
        ['Mfr.', manufacturer_name],
        ['Description', description_element],
        ['Lifecycle', lifecycle_text],
        ['Datasheet', datasheet_url],
        ['ECAD Model', ecad_model]
    ]

    return product_data

def extract_pricing_data(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,/;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'https://www.google.com/'
    }

    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, "html.parser")

    pricing_table = soup.find('table', class_='pricing-table')

    if pricing_table:
        pricing_rows = pricing_table.find_all('tr')

        quantity_list = []
        unit_price_list = []
        ext_price_list = []

        for row in pricing_rows[1:]:
            cols = row.find_all(['th', 'td'])

            # Check if the row has the expected number of columns
            if len(cols) >= 3:
                quantity = cols[0].text.strip()
                unit_price = cols[1].text.strip().replace('₹', 'INR ')
                ext_price = cols[2].text.strip().replace('₹', 'INR ')

                quantity_list.append(quantity)
                unit_price_list.append(unit_price)
                ext_price_list.append(ext_price)
            else:
                print(f"Skipping row: {cols} - Number of columns is not as expected.")

        pricing_data = [
            ['Pricing Data', ' ', ' '],
            ['Qty.', 'Unit Price', 'Ext. Price'],
        ]

        pricing_data.extend([
            [quantity, unit_price, ext_price] for quantity, unit_price, ext_price in zip(quantity_list, unit_price_list, ext_price_list)
        ])

        return pricing_data
    else:
        print("Pricing table not found on the page.")
        return None


def extract_specs_data(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,/;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'https://www.google.com/'
    }

    response = requests.get(url, headers=headers).text
    soup = BeautifulSoup(response.content, "html.parser")

    specs_table = soup.find('table', class_='specs-table')
    specs_rows = specs_table.find_all('tr')

    attribute_list = []
    value_list = []

    for row in specs_rows[1:]:
        cols = row.find_all(['td'])
        attribute = cols[0].text.strip()
        value = cols[1].text.strip()

        attribute_list.append(attribute)
        value_list.append(value)

    specs_data = [
        ['Specifications', ' ', ' '],
        ['Attributes', 'Values', ' ']
    ]

    specs_data.extend([
        [attribute, value, ' ', ' ', ' '] for attribute, value in zip(attribute_list, value_list)
    ])

    return specs_data



# Combining and writing to CSV
def combine_and_write_to_csv(product_url, output_filepath):
    # Extract data
    product_data = extract_product_data(product_url)
    pricing_data = extract_pricing_data(product_url)
    specs_data = extract_specs_data(product_url)

    # Write to CSV
    with open(output_filepath, "w", newline="", encoding="utf-8") as csv_file:
        csv_writer = csv.writer(csv_file)
        csv_writer.writerows(product_data + pricing_data + specs_data)

    logging.info(f"Data written to {output_filepath}")

# Scrape and save each product
def scrape_and_save_each_product(base_url, output_folder_path, sleep_duration=5):
    output_folder_path = Path(output_folder_path)
    output_folder_path.mkdir(parents=True, exist_ok=True)
    
    product_links = get_product_links(base_url)

    for product_url in product_links:
        mouser_no = product_url.split('/')[-1].split('?')[0]
        output_filename = f"{mouser_no}_data.csv"
        output_filepath = output_folder_path / output_filename
        
        combine_and_write_to_csv(product_url, output_filepath)
        
        logging.info(f"Data for {mouser_no} written to {output_filename} in folder {output_folder_path}")
        time.sleep(sleep_duration)


base_url = 'https://www.mouser.in/c/embedded-solutions/wireless-rf-modules/antennas/'
output_folder_path = r'C:\Users\HP\Desktop\mouser\MM5_Embedded Solutions\MM5_S1_Wireless & RF Modules\MM5_S1_G1_Antennas' # Update this path
scrape_and_save_each_product(base_url, output_folder_path)


# In[ ]:




