import turtle
import cv2
import numpy as np
from PIL import ImageGrab
import time

# Create a turtle object
my_turtle = turtle.Turtle()

# Set the color and width of the line
my_turtle.color("black")
my_turtle.pensize(3)

# Hide the turtle shape
my_turtle.hideturtle()
my_turtle.speed(1)

# Set up the turtle screen
screen = turtle.Screen()
screen.setup(width=1.0, height=1.0)  # Set screen dimensions to full screen

# Function to capture the turtle graphics screen as an image
def get_image():
    x, y, width, height = screen.getcanvas().winfo_rootx(), screen.getcanvas().winfo_rooty(), screen.window_width(), screen.window_height()
    image = ImageGrab.grab((x, y, x + width, y + height))
    return image

# Create a video writer object
output_filename = "capacitor.avi"
fourcc = cv2.VideoWriter_fourcc(*"MJPG")
fps = 45
video_writer = cv2.VideoWriter(output_filename, fourcc, fps, (screen.window_width(), screen.window_height()))

# Function to draw a line
def draw_line():
    start_time = time.time()
    while True:
        # Capture the turtle graphics screen as an image
        screen_image = get_image()

        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

        # Write the frame to the video file
        video_writer.write(frame)

        # Update the turtle graphics
        #my_turtle.forward(2)
        turtle.update()

        # Check for the exact duration of 10 seconds
        if time.time() - start_time >= 10:
            break

# Register the callback function for the "q" key press
def exit_program():
    turtle.bye()
    video_writer.release()

screen.onkey(exit_program, "q")
screen.listen()
import turtle

def draw_inductor():
    turtle.speed(1)
    turtle.penup()
    turtle.goto(-50, 0)
    turtle.pendown()
    turtle.setheading(90)
    turtle.circle(10,180)
    turtle.circle(3,180)
    turtle.circle(10,180)
    turtle.circle(3,180)
    turtle.circle(10,180)
    turtle.circle(3,180)
    turtle.circle(10,180)
    turtle.penup()
    turtle.hideturtle()
    turtle.done()

draw_inductor()


draw_line()

# Close the turtle graphics window
turtle.bye()

# When everything is done, release the video writer
video_writer.release()

print("The video was successfully saved.")
