from PIL import ImageGrab
import time

# Capture a screenshot
screenshot = ImageGrab.grab()

# Save the screenshot to a file (optional)
screenshot.save("screenshot.png")

# Wait for 5 seconds
time.sleep(5)

# Continue with your code here
