import turtle
import json

# Open the JSON file
with open("C:\\Users\\HP\\Desktop\\json1\\andgate1.json", "r") as json_file:
    data = json.load(json_file)

# Initialize the Turtle
t = turtle.Turtle()
t.speed(1)  # Adjust the speed as needed

# Iterate through the commands and execute them
for command in data["commands"]:
    action = command["action"]
    if action == "penup":
        t.penup()
    elif action == "pendown":
        t.pendown()
    elif action == "goto":
        x = command["x"]
        y = command["y"]
        t.goto(x, y)
    elif action == "setheading":
        angle = command["angle"]
        t.setheading(angle)
    elif action == "forward":
        distance = command["distance"]
        t.forward(distance)
    elif action == "circle":
        radius = command["radius"]
        extent = command["extent"]
        t.circle(radius, extent)

# Close the Turtle graphics window on click
turtle.exitonclick()
