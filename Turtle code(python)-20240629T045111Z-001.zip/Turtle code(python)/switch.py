import turtle
import cv2
import io
from PIL import Image
import numpy as np

# Create a turtle object
my_turtle = turtle.Turtle()

# Set the color and width of the lines
my_turtle.color("black")
my_turtle.pensize(3)

# Hide the turtle shape
my_turtle.hideturtle()

# Set the drawing speed
my_turtle.speed(1)  # Adjust the speed as desired

# Create a video writer object
output_video_filename = 'turtle_graphics.mp4'
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
video_writer = cv2.VideoWriter(output_video_filename, fourcc, 30.0, (800, 600))

# Set up the turtle screen
screen = turtle.Screen()
screen.setup(width=1000, height=800)

# Draw the horizontal line
my_turtle.penup()
my_turtle.goto(-250, 0)
my_turtle.pendown()
my_turtle.setheading(0)
my_turtle.forward(150)
my_turtle.circle(-3)

# Draw the switch
my_turtle.penup()
my_turtle.goto(-98, -2)
my_turtle.pendown()
my_turtle.setheading(40)
my_turtle.forward(90)







#draw the horizontal line
my_turtle.penup()
#my_turtle.circle(3)
my_turtle.goto(-10,0)
#my_turtle.circle(3)
my_turtle.pendown()
my_turtle.circle(3)
my_turtle.goto(150,0)


# Capture each frame and write to the video file
while True:
    # Capture the turtle graphics screen as an image
    screen_image = screen.getcanvas().postscript(colormode='color')
    img = Image.open(io.BytesIO(screen_image.encode('utf-8')))
    
    # Convert the image to BGR format for writing with cv2
    frame = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
    
    # Write the frame to the video file
    video_writer.write(frame)
    
    # Update the turtle graphics
    turtle.update()
    
    # Check for any exit condition
    # If you want to exit the loop based on a condition, add it here
    # For example, press 'q' to quit
    if turtle.Screen().keycode("q"):
        break

# Release the video writer and close the turtle graphics window
video_writer.release()
turtle.bye()
