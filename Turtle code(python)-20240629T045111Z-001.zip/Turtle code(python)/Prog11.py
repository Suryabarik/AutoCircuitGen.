def sub(num1,num2):
    return num1 - num2
if __name__ == "__main__":
    sub()
