import turtle as t

t.speed(1)
t.penup()
t.goto(0 , -100)
t.pendown()

t.pensize(2)


t.done()