# This program computes the square root of a number

# Define the number
# Prog10.py
def calculate_square_root(num):
    return num ** 0.5

if __name__ == "__main__":
    calculate_square_root()
