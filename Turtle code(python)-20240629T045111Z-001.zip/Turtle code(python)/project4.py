import turtle as t

t.speed(1)
t.penup()
t.goto(-100 , 0)
t.pendown()

t.pensize(2)
t.circle(100 , 360)

t.penup()
t.goto(-350 , 90)
t.pendown()

t.setheading(0)
t.forward(200)
t.pensize(3)
t.setheading(90)
t.forward(40)
t.setheading(270)
t.forward(80)
t.setheading(90)
t.forward(40)

t.setheading(60)
t.forward(70)

t.pensize(2)
t.setheading(90)
t.forward(100)

t.penup()
t.goto(-150 , 90)
t.pendown()

t.pensize(3)
t.setheading(300)
t.forward(70)

t.pensize(2)
t.setheading(270)
t.forward(100)

t.done()