import turtle
import cv2
import numpy as np
from PIL import ImageGrab
import time

# Create a turtle object
my_turtle = turtle.Turtle()

# Set the color and width of the lines
my_turtle.color("blue")
my_turtle.pensize(3)

# Hide the turtle shape
my_turtle.hideturtle()

# Set up the turtle screen
screen = turtle.Screen()
screen.setup(width=1.0, height=1.0)  # Set screen dimensions to full screen

# Function to capture the turtle graphics screen as an image
def get_image():
    x, y, width, height = screen.getcanvas().winfo_rootx(), screen.getcanvas().winfo_rooty(), screen.window_width(), screen.window_height()
    image = ImageGrab.grab((x, y, x + width, y + height))
    return image

# Create a video writer object
output_filename = "C:\\Users\\HP\\Desktop\\videocreation\\circuit1.avi"
# output_filename = "C:/Users/MY PC/Desktop/TempCode/circuit3.avi"
fourcc = cv2.VideoWriter_fourcc(*"MJPG")
fps = 30
video_writer = cv2.VideoWriter(output_filename, fourcc, fps, (screen.window_width(), screen.window_height()))

# Define the duration for each drawing operation
duration = 2  # Duration in seconds

def draw_resistor():
    start_time = time.time()
    my_turtle.penup()
    my_turtle.goto(-70, -35)
    my_turtle.pendown()
    my_turtle.setheading(0)
    for _ in range(25):
        my_turtle.forward(2)
        time.sleep(0.01)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()

        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

        # Write the frame to the video file
        video_writer.write(frame)
    # Draw the Resistor
    my_turtle.penup()
    my_turtle.goto(-20, -50)
    my_turtle.pendown()
    my_turtle.setheading(90)
    #my_turtle.forward(30)
    for _ in range(15):
        my_turtle.forward(2)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()

        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

        # Write the frame to the video file
        video_writer.write(frame)
    my_turtle.right(90)
    #my_turtle.forward(90)
    for _ in range(45):
        my_turtle.forward(2)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()

        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

        # Write the frame to the video file
        video_writer.write(frame)
    my_turtle.right(90)
    #my_turtle.forward(30)
    for _ in range(15):
        my_turtle.forward(2)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()

        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

        # Write the frame to the video file
        video_writer.write(frame)
    my_turtle.right(90)
    #my_turtle.forward(90)
    for _ in range(45):
        my_turtle.forward(2)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()

        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

        # Write the frame to the video file
        video_writer.write(frame)
    my_turtle.right(90)
    # Draw the horizontal line
    my_turtle.penup()
    my_turtle.goto(70,-35)
    my_turtle.pendown()
    my_turtle.goto(160,-35)

    my_turtle.setheading(90)
    #my_turtle.forward(185)
    for _ in range(185):
        my_turtle.forward(1)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()

        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

        # Write the frame to the video file
        video_writer.write(frame)
def draw_cell():
    my_turtle.penup()
    my_turtle.goto(10, 150)
    my_turtle.pendown()
    my_turtle.setheading(0)
    #my_turtle.forward(150)
    for _ in range(50):
        my_turtle.forward(3)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()

        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

        # Write the frame to the video file
        video_writer.write(frame)
    # Draw the vertical line
    my_turtle.penup()
    my_turtle.goto(10, 140)
    my_turtle.pendown()
    my_turtle.setheading(90)
    #my_turtle.forward(20)
    for _ in range(10):
        my_turtle.forward(2)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()

        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

        # Write the frame to the video file
        video_writer.write(frame)
    # Draw the second set of lines
    distance = 5  # Distance from the vertical line
    # Draw the horizontal line
    my_turtle.penup()
    my_turtle.goto(-5, 150)
    my_turtle.pendown()
    my_turtle.setheading(0)
    #my_turtle.forward(-70)
    for _ in range(35):
        my_turtle.backward(2)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()

        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

        # Write the frame to the video file
        video_writer.write(frame)
    # Draw the vertical line
    my_turtle.penup()
    my_turtle.goto(-10 + distance, 133)
    my_turtle.pendown()
    my_turtle.setheading(90)
    #my_turtle.forward(35)
    for _ in range(35):
        my_turtle.forward(1)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()

        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

        # Write the frame to the video file
        video_writer.write(frame)
def draw_switch():
    # Draw the tiny circle
    my_turtle.penup()
    my_turtle.goto(-75, 150)
    my_turtle.pendown()
    my_turtle.circle(3)
    #draw the horizontal line
    my_turtle.penup()
    my_turtle.goto(-150,150)
    my_turtle.pendown()
    my_turtle.circle(3)
    my_turtle.setheading(0)
    my_turtle.goto(-80,175)
    my_turtle.circle(3)
    # Draw the switch
    my_turtle.penup()
    my_turtle.goto(-157, 150)
    my_turtle.pendown()
    my_turtle.setheading(0)
    #my_turtle.forward(-60)
    for _ in range(30):
        my_turtle.backward(2)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()

        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

        # Write the frame to the video file
        video_writer.write(frame)
    my_turtle.right(90)
    #my_turtle.forward(50)
    for _ in range(25):
        my_turtle.forward(2)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()

        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)

        # Write the frame to the video file
        video_writer.write(frame)
def draw_bulb():
    #DRAW THE BULB
    #circle
    center_x = -240  # X-coordinate of the center
    center_y = 100 # Y-coordinate of the center
    radius = 25  # Radius of the circle
    # Move the turtle to the center point
    my_turtle.penup()
    my_turtle.goto(center_x, center_y - radius)
    my_turtle.pendown()
    # Draw the circle
    my_turtle.circle(radius)
    #diagonals
    my_turtle.penup()
    my_turtle.goto(-237,60 )
    my_turtle.pendown()
    my_turtle.setheading(30)
    #my_turtle.forward(50)
    for _ in range(25):
        my_turtle.forward(2)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()
        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)
        # Write the frame to the video file
        video_writer.write(frame)
    my_turtle.penup()
    my_turtle.goto(-194, 60)
    my_turtle.pendown()
    my_turtle.setheading(145)
    #my_turtle.forward(50)
    for _ in range(25):
        my_turtle.forward(2)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()
        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)
        # Write the frame to the video file
        video_writer.write(frame)
    my_turtle.penup()
    my_turtle.goto(-70,-35)
    my_turtle.pendown()
    my_turtle.setheading(180)
    #my_turtle.forward(145)
    for _ in range(145):
        my_turtle.forward(1)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()
        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)
        # Write the frame to the video file
        video_writer.write(frame)
    my_turtle.right(90)
    #my_turtle.forward(86)
    for _ in range(43):
        my_turtle.forward(2)
        time.sleep(0.0001)
        # Capture the turtle graphics screen as an image
        screen_image = get_image()
        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)
        # Write the frame to the video file
        video_writer.write(frame)
     # Check for the exact duration of 10 seconds
    start_time = time.time()
    while time.time() - start_time < 10:
        screen_image = get_image()
        # Convert the image to BGR format for writing with cv2
        frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)
        # Write the frame to the video file
        video_writer.write(frame)
        time.sleep(0.0001)
      
def exit_program():
    turtle.bye()
    video_writer.release()

screen.onkey(exit_program, "q")
screen.listen()

# Start drawing the diode
draw_resistor()
draw_cell()
draw_switch()
draw_bulb()

# Close the turtle graphics window
turtle.bye()

# When everything is done, release the video writer
video_writer.release()

print("The video was successfully saved.")
