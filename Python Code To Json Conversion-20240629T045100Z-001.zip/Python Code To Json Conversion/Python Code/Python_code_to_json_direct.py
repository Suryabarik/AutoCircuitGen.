import ast
import json

def convert_command(command, args):
    command_map = {
        'penup': 'penup',
        'pendown': 'pendown',
        'pensize': 'pensize',
        'setheading': 'setheading',
        'forward': 'forward',
        'goto': 'goto',
        'backward': 'backward',
        'right': 'right',
        'left': 'left',
        'circle': 'circle',
        'write':'write'
    }

    json_command = {"action": command_map.get(command, command), "duration": 0}

    if command == 'goto':
        json_command['x'] = args[0]
        json_command['y'] = args[1]
    elif command == 'pensize':
        json_command['size'] = args[0]
    elif command == 'setheading':
        json_command['angle'] = args[0]
    elif command == 'forward':
        json_command['distance'] = args[0]
    elif command == 'backward':
        json_command['distance'] = args[0]
    elif command == 'right':
        json_command['angle'] = args[0]
    elif command == 'left':
        json_command['angle'] = args[0]
    elif command == 'circle':
        json_command['radius'] = args[0]
        json_command['extent'] = args[1]  # Assuming extent is the second element in args
    elif command == 'write':
        json_command['action'] = 'write'
        json_command['text'] = args[0] if len(args) >= 1 else ""
        json_command['font'] = [args[1], args[2], args[3]] if len(args) >= 4 else ["Arial", 7, "normal"]

    return json_command

def python_code_to_json_file(input_file, output_file):
    with open(input_file, 'r') as file:
        python_code = file.read()

    commands = []
    command_list = ast.parse(python_code).body

    for item in command_list:
        if isinstance(item, ast.Expr) and isinstance(item.value, ast.Call):
            func = item.value.func.attr
            args = []
            for arg in item.value.args:
                if isinstance(arg, ast.Tuple):
                    args.extend([ast.literal_eval(a) for a in arg.elts])
                else:
                    args.append(ast.literal_eval(arg))
            command = convert_command(func, args)
            commands.append(command)

    json_representation = {"title": "Turtle Graphics", "commands": commands}

    with open(output_file, 'w') as file:
        json.dump(json_representation, file, indent=2)

# File paths
input_python_file = 'C:\\Users\\HP\\Downloads\\Stepper_motor (1).py'
output_json_file = 'C:\\Users\\HP\\Desktop\\innopython_To_Json_conveter\\Stepper_motor (1).json'

# Convert Turtle graphics code from Python file to JSON file
python_code_to_json_file(input_python_file, output_json_file)
