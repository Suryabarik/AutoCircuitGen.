import turtle
import cv2
import numpy as np
from PIL import ImageGrab
import time
import json

# Create a turtle object
my_turtle = turtle.Turtle()
my_turtle.color("black")
my_turtle.pensize(3)
# Set up the turtle screen
screen = turtle.Screen()
screen.setup(width=1.0, height=1.0)  # Set screen dimensions to full screen

# Function to capture the turtle graphics screen as an image
def get_image():
    x, y, width, height = screen.getcanvas().winfo_rootx(), screen.getcanvas().winfo_rooty(), screen.window_width(), screen.window_height()
    image = ImageGrab.grab((x, y, x + width, y + height))
    return image

# Create a video writer object
output_filename = "C:\\Users\\HP\\Desktop\\videocreation\\ARM.avi"
fourcc = cv2.VideoWriter_fourcc(*"MJPG")
fps = 30
video_writer = cv2.VideoWriter(output_filename, fourcc, fps, (screen.window_width(), screen.window_height()))

# Read the JSON file with drawing instructions
with open('C:\\Users\\HP\\Desktop\\innopython_To_Json_conveter\\Stepper_motor (1).json', 'r') as json_file:
    data = json.load(json_file)

# Loop through the commands and execute actions
for command in data["commands"]:
    action = command["action"]
    if action == "penup":
        my_turtle.penup()
    elif action == "pendown":
        my_turtle.pendown()
    elif action == "goto":
        x = command.get("x", 0)
        y = command.get("y", 0)
        my_turtle.goto(x, y)
    elif action == "setheading":
        angle = command.get("angle", 0)
        my_turtle.setheading(angle)
    elif action == "forward":
        distance = command.get("distance", 0)
        my_turtle.forward(distance)
    elif action == "backward":
        distance = command.get("distance", 0)
        my_turtle.backward(distance)
    elif action == "right":
        angle = command.get("angle", 0)
        my_turtle.right(angle)
    elif action == "left":
        angle = command.get("angle", 0)
        my_turtle.right(angle)
    elif action == "circle":
        radius = command.get("radius", 0)  # Default to 0 if "radius" is not present in the command
        extent = command.get("extent", 360)  # Default to 360 if "extent" is not present in the command
        my_turtle.circle(radius, extent)
    elif action == "for":
        num_iterations = command.get("range", 1)
        sub_commands = command.get("commands", [])
    elif action == "write":
        text = command.get("text", "")
        font = tuple(command.get("font", ["Arial", 12, "normal"]))  # Default font values if not provided
        my_turtle.write(text, font=font)

    elif action == "for":
        num_iterations = command.get("range", 1)
        sub_commands = command.get("commands", [])
        for _ in range(num_iterations):
            for sub_command in sub_commands:
                sub_action = sub_command["action"]
                if sub_action == "forward":
                    sub_distance = sub_command.get("distance", 0)
                    my_turtle.forward(sub_distance)
                elif sub_action == "backward":
                    sub_distance = sub_command.get("distance", 0)
                    my_turtle.backward(sub_distance)
                elif sub_action == "penup":
                    my_turtle.penup()
                elif sub_action == "pendown":
                    my_turtle.pendown()
                elif sub_action == "goto":
                    sub_x = sub_command.get("x", 0)
                    sub_y = sub_command.get("y", 0)
                    my_turtle.goto(sub_x, sub_y)
                elif sub_action == "setheading":
                    sub_angle = sub_command.get("angle", 0)
                    my_turtle.setheading(sub_angle)
                elif action == "write":
                 text = command.get("text", "")
                 font = tuple(command.get("font", ["Arial", 12, "normal"]))  # Default font values if not provided
                 my_turtle.write(text, font=font)
                elif sub_action == "write":  # Fix here: check sub_action for "write"
                    text = sub_command.get("text", "")
                    font = tuple(sub_command.get("font", ["Arial", 12, "normal"]))  # Default font values if not provided
                    my_turtle.write(text, font=font)
                elif sub_action == "duration":
                    duration = sub_command.get("duration", 0)
                    time.sleep(duration)
                    # Capture the turtle graphics screen as an image
                    screen_image = get_image()
                    # Convert the image to BGR format for writing with cv2
                    frame = cv2.cvtColor(np.array(screen_image), cv2.COLOR_RGB2BGR)
                    # Write the frame to the video file
                    video_writer.write(frame)
                    

# Close the turtle graphics window
turtle.bye()

# When everything is done, release the video writer
video_writer.release()

print("The video was successfully saved.")
